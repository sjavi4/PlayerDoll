package me.autobot.playerdoll.Inject;

import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import me.autobot.playerdoll.Proxy;

import java.lang.reflect.Method;
import java.util.logging.Level;

public class DollChannelInitializer extends ChannelInitializer<Channel> {
    private final ChannelInitializer<Channel> original;
    private Method method;

    public DollChannelInitializer(ChannelInitializer<Channel> oldInit) {
        this.original = oldInit;
        try {
            this.method = ChannelInitializer.class.getDeclaredMethod("initChannel", Channel.class);
            this.method.setAccessible(true);
        } catch (NoSuchMethodException e) {
            Proxy.getInstance().getLogger().log(Level.WARNING, "Failed to get initChannel method", e);
        }
    }
    @Override
    protected void initChannel(Channel channel) throws Exception {
        if (!channel.isActive()) {
            return;
        }
        if (!Proxy.dollConnections.containsKey(channel.localAddress().toString())) {
            return;
        }

        //UserConnection info = new UserConnectionImpl(socketChannel);
        // init protocol
        //new ProtocolPipelineImpl(info);
        // Add originals
        this.method.invoke(this.original, channel);

        if (!channel.isActive()) return; // Don't inject if inactive
        if (channel.pipeline().get("packet-encoder") == null) return; // Don't inject if no packet-encoder
        if (channel.pipeline().get("packet-decoder") == null) return; // Don't inject if no packet-decoder
        // Add our transformers
        //BungeeEncodeHandler encoder = new BungeeEncodeHandler(info);
        //BungeeDecodeHandler decoder = new BungeeDecodeHandler(info);

        //channel.pipeline().addBefore("packet-encoder", "via-encoder", encoder);
        //channel.pipeline().addBefore("packet-decoder", "via-decoder", decoder);
    }

    public ChannelInitializer<Channel> getOriginal() {
        return original;
    }
}
