package me.autobot.playerdoll.Inject;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import net.md_5.bungee.api.ProxyServer;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Injector {
    private static final Field LISTENERS_FIELD;
    private final List<Channel> injectedChannels = new ArrayList<>();

    static {
        try {
            LISTENERS_FIELD = ProxyServer.getInstance().getClass().getDeclaredField("listeners");
            LISTENERS_FIELD.setAccessible(true);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException("Unable to access listeners field.", e);
        }
    }

    @SuppressWarnings("unchecked")
    public void inject() throws ReflectiveOperationException {
        Set<Channel> listeners = (Set<Channel>) LISTENERS_FIELD.get(ProxyServer.getInstance());

        // Inject the list
        Set<Channel> wrapper = new ViaSetWrapper<>(listeners, channel -> {
            try {
                injectChannel(channel);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        LISTENERS_FIELD.set(ProxyServer.getInstance(), wrapper);

        // Iterate through current list
        for (Channel channel : listeners) {
            injectChannel(channel);
        }
    }
    @SuppressWarnings("unchecked")
    private void injectChannel(Channel channel) throws ReflectiveOperationException {
        List<String> names = channel.pipeline().names();
        ChannelHandler bootstrapAcceptor = null;

        for (String name : names) {
            ChannelHandler handler = channel.pipeline().get(name);
            try {
                Field child = handler.getClass().getDeclaredField("childHandler");
                child.setAccessible(true);
                ChannelInitializer.class.cast(child.get(handler));
                //ReflectionUtil.get(handler, "childHandler", ChannelInitializer.class);
                bootstrapAcceptor = handler;
            } catch (Exception e) {
                // Not this one
            }
        }

        // Default to first
        if (bootstrapAcceptor == null) {
            bootstrapAcceptor = channel.pipeline().first();
        }

        if (bootstrapAcceptor.getClass().getName().equals("net.md_5.bungee.query.QueryHandler")) {
            return;
        }

        try {
            //ChannelInitializer<Channel> oldInit = ReflectionUtil.get(bootstrapAcceptor, "childHandler", ChannelInitializer.class);
            //ChannelInitializer<Channel> newInit = new BungeeChannelInitializer(oldInit);
            Field old = bootstrapAcceptor.getClass().getDeclaredField("childHandler");
            old.setAccessible(true);
            ChannelInitializer<Channel> oldInit = (ChannelInitializer<Channel>) old.get(bootstrapAcceptor);



            //ReflectionUtil.set(bootstrapAcceptor, "childHandler", newInit);
            this.injectedChannels.add(channel);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException("Unable to find core component 'childHandler', please check your plugins. issue: " + bootstrapAcceptor.getClass().getName());
        }
    }
}
